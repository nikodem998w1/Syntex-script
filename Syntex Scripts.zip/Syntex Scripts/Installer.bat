@echo off
title Syntex Script Installer
color 0A
setlocal

set "URL=https://raw.githubusercontent.com/nikodem998w1/Syntex-script/main/Syntex%%20script.bat"
set "DEST=%~dp0Syntex Script.bat"

echo.
echo =================================
echo       SYNTEX SCRIPT INSTALLER
echo =================================
echo.
echo Downloading Syntex Script...
echo.

curl.exe -fL --retry 3 --retry-delay 2 -o "%DEST%" "%URL%"

if errorlevel 1 (
    echo.
    echo Download failed!
    del "%DEST%" >nul 2>&1
    echo.
    echo Press ENTER to close...
    pause >nul
    exit /b 1
)

echo.
echo Download completed successfully!
echo.
echo File saved:
echo %DEST%
echo.
echo Press ENTER to close...

pause >nul
exit /b 0