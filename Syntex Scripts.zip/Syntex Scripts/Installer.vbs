Dim answer
Dim shell

Set shell = CreateObject("WScript.Shell")

answer = MsgBox("Do you want to install Syntex Script?", vbYesNo + vbQuestion, "Installer")

If answer = vbYes Then
    shell.Run """Installer.bat"""
ElseIf answer = vbNo Then
    WScript.Quit
End If